//Declare all your variables, objects, and arrays.
var redPaintButton, bluePaintButton,
  greenPaintButton, yellowPaintButton, blackPaintButton;
let pictures = [];
let currentColor = "white";
var cloudButton1, cloudButton2, cloudButton3, backButton;
let cloudY, cloud1X, cloud2X, cloud3X;
let cloudsWidth, cloudsHeight;
let cloudArea;
let images = [];
let x = [157, 178, 240, 342, 31, 400, 146, 162, 30, 90, 53, 34, 234, 170, 318];
let y = [268, 152, 226, 345, 30, 130, 221, 138, 230, 258, 437, 152, 375, 483, 52];
let W = [180, 105, 105, 260, 550, 196, 225, 151, 470, 255, 386, 372, 140, 150, 70];
let H = [315, 83, 230, 165, 82, 135, 273, 158, 225, 143, 120, 100, 136, 33, 65];
let BG1, BG2;
let game1, game2, game3 = false;
let colorGameInstructions = false;
let colorGameNextButton;
let newLetter;
let enteringKey = false;
let typeLetterA = false;
let typeLetterB = false;
let typeLetterC = false;
let typeEasyWordA = false;
let typeEasyWordB = false;
let typeEasyWordC = false;
let typeHardWordA = false;
let hardWordAPart1, hardWordAPart2, hardWordAPart3, hardWordAPart4, hardWordAPart5, hardWordAPart6 = false;
let hardWordBPart1, hardWordBPart2, hardWordBPart3, hardWordBPart4, hardWordBPart5, hardWordBPart6 = false;
let hardWordCPart1, hardWordCPart2, hardWordCPart3, hardWordCPart4, hardWordCPart5, hardWordCPart6 = false;
let typeHardWordB = false;
let typeHardWordC = false;
let keyboardGame1 = false
let keyboardGame2 = false
let keyboardGame3 = false
let letterA;
let letterB;
let letterC;
let easyWordA;
let easyWordAPart1, easyWordAPart2, easyWordAPart3, easyWordAPart4 = false;
let easyWordBPart1, easyWordBPart2, easyWordBPart3, easyWordBPart4 = false;
let easyWordCPart1, easyWordCPart2, easyWordCPart3, easyWordCPart4 = false;
let easyWordB;
let easyWordC;
let nextLetter;
let keyboardGameCounter = 0;
let keyboardGameCounterWrong = 0;
let curLetter = newLetter;
let keyboardGameButton;
let keyboardGame2Button;
let keyboardGame3Button;
let keyboardGame1RestartButton;
let keyboardGameWin = false;
var letters = ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x", "c", "v", "b", "n", "m"];

var easyWords = ["come", "camp", "bear", "play", "sing", "bird", "bean", "game", "rice", "four", "five", "love", "work", "dark", "lake", "bang"];

var hardWords = ["purple", "orange", "family", "twelve", "silver", "thirty", "donate", "people", "future", "heaven", "banana", "africa", "monday", "picnic", "nature", "eleven"];

var keyboardB = [];
let keyboardX = 60;
let keyboardY = 350;

let circlEx = 400;
let circlEy = 130;
let diameter = 20;
let dragging = false;
let greenFlag;
let circleGameWin = false;
let circleGameLoss = false;
let startCircleGame = false;
let startCircleGameText;
let circleGameButton
let restartCircleGameButton;
let startCircleGameloosingText = false
let startCircleGame2loosingText = false
let startCircleGame2Text = false
let circleGamePart1, circleGamePart2 = false;
var timerValue = 10;
var fade;
var fadeAmount = 1
// Load images through for loops in preload function.
function preload() {
  mainPageBackground = loadImage("cloudPicture.jpg");
  gameBackground = loadImage("cloud-aesthetic-picture.png");
  BG1 = loadImage("background1.png");
  BG2 = loadImage("background2.png");


  for (let i = 0; i < 15; i++) {
    images[i] = loadImage(`art/image${i}.png`);
  }
}
// Setup function Bullshit/-----------------------------------------------------------------------
function setup() {
  createCanvas(700, 700);
  textSize(20);
  background(gameBackground);
  //Draw credits text.
  rect(90, 440, 520, 100)
  fill(0);
  text("Created by:", 280, 460);
  text("Andrew Ayerh, Brian Martinez Rosas, Maggie Nguyen,", 110, 500);
  text("Pranav Pokar, Kiernan Wyatt", 220, 530);
  textSize(40)
  text("Click on one of the 3 clouds below!",40,100)
  fill(500);

  // Calculate the values for the variables.
  cloudY = 240;
  cloud1X = 0;
  cloud2X = cloud1X + 235;
  cloud3X = cloud2X + 235;
  // create Buttons
  cloudButton1 = createImg('art/Screenshot 2022-10-14 133350 copy (1).png');
  cloudButton2 = createImg('art/Screenshot 2022-10-14 133350 copy (1).png');
  cloudButton3 = createImg('art/Screenshot 2022-10-14 133350 copy (1).png');
  backButton = createButton('Back');
  // Position each Button.
  cloudButton1.position(cloud1X, cloudY);
  cloudButton2.position(cloud2X, cloudY);
  cloudButton3.position(cloud3X, cloudY);
  backButton.position(20, height - 50);
  // Size each Button
  cloudsWidth = 220;
  cloudsHeight = 150;

  cloudButton1.size(cloudsWidth, cloudsHeight);
  cloudButton2.size(cloudsWidth, cloudsHeight);
  cloudButton3.size(cloudsWidth, cloudsHeight);
  // Set each Button to it's respective function.
  cloudButton1.mousePressed(circleGame);
  cloudButton2.mousePressed(paintGame);
  cloudButton3.mousePressed(keyboardGame);
  backButton.mousePressed(goBack);

  restartCircleGameButton = createButton("Restart");
  restartCircleGameButton.position(300,300);
  restartCircleGameButton.size(80,50);
  restartCircleGameButton.mousePressed(RCG);
  restartCircleGameButton.hide();
  //hide unneeded buttons at first.
  backButton.hide();
  //declare new objects
  let assignedX0, assignedX1, assignedX2, assignedX3, assignedX4, assignedX5, assignedX6, assignedX7, assignedX8, assignedX9, assignedX10, assignedX11, assignedX12, assignedX13, assignedX14 = 0;
  let assignedY0, assignedY1, assignedY2, assignedY3, assignedY4, assignedY5, assignedY6, assignedY7, assignedY8, assignedY9, assignedY10, assignedY11, assignedY12, assignedY13, assignedY14 = 0;
  let assignedW0, assignedW00, assignedW1, assignedW2, assignedW3, assignedW4, assignedW5, assignedW6, assignedW7, assignedW8, assignedW9, assignedW10, assignedW11, assignedW12, assignedW13, assignedW14 = 0;
  let
    assignedH0, assignedH1, assignedH2, assignedH3, assignedH4, assignedH5, assignedH6, assignedH7, assignedH8, assignedH9, assignedH10, assignedH11, assignedH12, assignedH13, assignedH14 = 0;

  //for loops that are assigninging each X, Y, R, to a class. ex: X1, Y1, W1, H1 = newBubble1.

  for (let i = 0; i < 15; i++) {
    if (i == 1) {
      assignedX1 = x[i];
      assignedY1 = y[i];
      assignedW1 = W[i];
      assignedH1 = H[i];
      let b1 = new Bubble1(assignedX1, assignedY1, assignedW1, assignedH1, images);
      pictures.push(b1);

    }
    if (i == 3) {
      assignedX3 = x[i];
      assignedY3 = y[i];
      assignedW3 = W[i];
      assignedH3 = H[i];
      let b3 = new Bubble3(assignedX3, assignedY3, assignedW3, assignedH3, images);
      pictures.push(b3);

    }
    if (i == 4) {
      assignedX4 = x[i];
      assignedY4 = y[i];
      assignedW4 = W[i];
      assignedH4 = H[i];
      let b4 = new Bubble4(assignedX4, assignedY4, assignedW4, assignedH4, images);
      pictures.push(b4);

    }
    if (i == 5) {
      assignedX5 = x[i];
      assignedY5 = y[i];
      assignedW5 = W[i];
      assignedH5 = H[i];
      let b5 = new Bubble5(assignedX5, assignedY5, assignedW5, assignedH5, images);
      pictures.push(b5);

    }
    if (i == 6) {
      assignedX6 = x[i];
      assignedY6 = y[i];
      assignedW6 = W[i];
      assignedH6 = H[i];
      let b6 = new Bubble6(assignedX6, assignedY6, assignedW6, assignedH6, images);
      pictures.push(b6);

    }
    if (i == 7) {
      assignedX7 = x[i];
      assignedY7 = y[i];
      assignedW7 = W[i];
      assignedH7 = H[i];
      let b7 = new Bubble7(assignedX7, assignedY7, assignedW7, assignedH7, images);
      pictures.push(b7);

    }
    if (i == 8) {
      assignedX8 = x[i];
      assignedY8 = y[i];
      assignedW8 = W[i];
      assignedH8 = H[i];
      let b8 = new Bubble8(assignedX8, assignedY8, assignedW8, assignedH8, images);
      pictures.push(b8);

    }
    if (i == 9) {
      assignedX9 = x[i];
      assignedY9 = y[i];
      assignedW9 = W[i];
      assignedH9 = H[i];
      let b9 = new Bubble9(assignedX9, assignedY9, assignedW9, assignedH9, images);
      pictures.push(b9);

    }
    if (i == 10) {
      assignedX10 = x[i];
      assignedY10 = y[i];
      assignedW10 = W[i];
      assignedH10 = H[i];
      let b10 = new Bubble10(assignedX10, assignedY10, assignedW10, assignedH10, images);
      pictures.push(b10);

    }
    if (i == 11) {
      assignedX11 = x[i];
      assignedY11 = y[i];
      assignedW11 = W[i];
      assignedH11 = H[i];
      let b11 = new Bubble11(assignedX11, assignedY11, assignedW11, assignedH11, images);
      pictures.push(b11);

    }
    if (i == 12) {
      assignedX12 = x[i];
      assignedY12 = y[i];
      assignedW12 = W[i];
      assignedH12 = H[i];
      let b12 = new Bubble12(assignedX12, assignedY12, assignedW12, assignedH12, images);
      pictures.push(b12);

    }
    if (i == 13) {
      assignedX13 = x[i];
      assignedY13 = y[i];
      assignedW13 = W[i];
      assignedH13 = H[i];
      let b13 = new Bubble13(assignedX13, assignedY13, assignedW13, assignedH13, images);
      pictures.push(b13);

    }
    if (i == 14) {
      assignedX14 = x[i];
      assignedY14 = y[i];
      assignedW14 = W[i];
      assignedH14 = H[i];
      let b14 = new Bubble14(assignedX14, assignedY14, assignedW14, assignedH14, images);
      pictures.push(b14);

    }
  }
  redPaintButton = createButton("____");
  redPaintButton.style('background-color', "red");
  bluePaintButton = createButton("____");
  bluePaintButton.style('background-color', "blue");
  greenPaintButton = createButton("____");
  greenPaintButton.style('background-color', "green");
  yellowPaintButton = createButton("____");
  yellowPaintButton.style('background-color', "yellow");
  blackPaintButton = createButton("____");
  blackPaintButton.style('background-color', "black");
  
colorGameNextButton = createButton("Let's Paint!");
  colorGameNextButton.position(250,375)
  colorGameNextButton.size(200,50);
  colorGameNextButton.mousePressed(colorGameNext);
  colorGameNextButton.hide();
  
  redPaintButton.mousePressed(changeColorToRed);
  bluePaintButton.mousePressed(changeColorToBlue);
  greenPaintButton.mousePressed(changeColorToGreen);
  yellowPaintButton.mousePressed(changeColorToYellow);
  blackPaintButton.mousePressed(changeColorToBlack);

  redPaintButton.position(612,50);
  bluePaintButton.position(612,120);
  greenPaintButton.position(612,190);
  yellowPaintButton.position(612,260);
  blackPaintButton.position(612,330);

  redPaintButton.size(88,60);
  bluePaintButton.size(88,60);
  greenPaintButton.size(88,60);
  yellowPaintButton.size(88,60);
  blackPaintButton.size(88,60);
  
  redPaintButton.hide();
  bluePaintButton.hide();
  greenPaintButton.hide();
  yellowPaintButton.hide();
  blackPaintButton.hide();

  keyboardGame2Button = createButton("NEXT");
  keyboardGame2Button.position(350, 350);
  keyboardGame2Button.mousePressed(enterKeyboardGame2);
  keyboardGame2Button.hide();

  keyboardGame3Button = createButton("NEXT");
  keyboardGame3Button.position(250, 300);
  keyboardGame3Button.mousePressed(enterKeyboardGame3);
  keyboardGame3Button.size(200, 100);
  keyboardGame3Button.hide();

  keyboardGame1RestartButton = createButton("Restart");
  keyboardGame1RestartButton.position(350, 350);
  keyboardGame1RestartButton.mousePressed(restartKeyboardGame1);
  keyboardGame1RestartButton.hide();

  letterA = random(letters);
  letterB = random(letters);
  letterC = random(letters);

  easyWordA = random(easyWords);
  easyWordB = random(easyWords);
  easyWordC = random(easyWords);

  hardWordA = random(hardWords);
  hardWordB = random(hardWords);
  hardWordC = random(hardWords);

  textSize(40)
  //text(newLetter, 200, 200);
  for (let i = 0; i <= 9; i++) {
    keyboardB[i] = createButton(letters[i])
    keyboardB[i].size(60, 60);
    keyboardB[i].position(keyboardX + [i] * 64, keyboardY);
    keyboardB[i].hide();
  }
  for (let i = 10; i <= 18; i++) {
    keyboardB[i] = createButton(letters[i])
    keyboardB[i].size(70, 70);
    keyboardB[i].position(keyboardX + [i] * 74 - 780, keyboardY + 70);
    keyboardB[i].hide();
  }
  for (let i = 19; i <= 25; i++) {
    keyboardB[i] = createButton(letters[i])
    keyboardB[i].size(70, 70);
    keyboardB[i].position(keyboardX + [i] * 74 - 1400, keyboardY + 150);
    keyboardB[i].hide();
  }
  keyboardB[0].mousePressed(enterLet0);
  keyboardB[1].mousePressed(enterLet1);
  keyboardB[2].mousePressed(enterLet2);
  keyboardB[3].mousePressed(enterLet3);
  keyboardB[4].mousePressed(enterLet4);
  keyboardB[5].mousePressed(enterLet5);
  keyboardB[6].mousePressed(enterLet6);
  keyboardB[7].mousePressed(enterLet7);
  keyboardB[8].mousePressed(enterLet8);
  keyboardB[9].mousePressed(enterLet9);
  keyboardB[10].mousePressed(enterLet10);
  keyboardB[11].mousePressed(enterLet11);
  keyboardB[12].mousePressed(enterLet12);
  keyboardB[13].mousePressed(enterLet13);
  keyboardB[14].mousePressed(enterLet14);
  keyboardB[15].mousePressed(enterLet15);
  keyboardB[16].mousePressed(enterLet16);
  keyboardB[17].mousePressed(enterLet17);
  keyboardB[18].mousePressed(enterLet18);
  keyboardB[19].mousePressed(enterLet19);
  keyboardB[20].mousePressed(enterLet20);
  keyboardB[21].mousePressed(enterLet21);
  keyboardB[22].mousePressed(enterLet22);
  keyboardB[23].mousePressed(enterLet23);
  keyboardB[24].mousePressed(enterLet24);
  keyboardB[25].mousePressed(enterLet25);

  setInterval(timeIt, 1000);
}
//------------------------------------------------------------------------------------------------

function mousePressed() {
  if (game2 == true) {
    for (let i = 0; i < pictures.length; i++) {
      pictures[i].clicked(mouseX, mouseY);
    }
  }
  if (game1 == true) {
    if (dist(circlEx, circlEy, mouseX, mouseY) < diameter / 2) {
      dragging = true;
    }
  }
}
function mouseReleased() {
  dragging = false;
}
function colorGameNext(){
  game2 = true;
  colorGameInstructions = false;
}
function RCG(){
  circleGamePart1 = true;
  circleGamePart2 = false;
  circlEx = 400;
  circlEy = 130;
  circleGameLoss = false;
  restartCircleGameButton.hide();
  timerValue = 10;
}

function enterLet0() { curLetter = letters[0]; enteringKey = true; }
function enterLet1() { curLetter = letters[1]; enteringKey = true; }
function enterLet2() { curLetter = letters[2]; enteringKey = true; }
function enterLet3() { curLetter = letters[3]; enteringKey = true; }
function enterLet4() { curLetter = letters[4]; enteringKey = true; }
function enterLet5() { curLetter = letters[5]; enteringKey = true; }
function enterLet6() { curLetter = letters[6]; enteringKey = true; }
function enterLet7() { curLetter = letters[7]; enteringKey = true; }
function enterLet8() { curLetter = letters[8]; enteringKey = true; }
function enterLet9() { curLetter = letters[9]; enteringKey = true; }
function enterLet10() { curLetter = letters[10]; enteringKey = true; }
function enterLet11() { curLetter = letters[11]; enteringKey = true; }
function enterLet12() { curLetter = letters[12]; enteringKey = true; }
function enterLet13() { curLetter = letters[13]; enteringKey = true; }
function enterLet14() { curLetter = letters[14]; enteringKey = true; }
function enterLet15() { curLetter = letters[15]; enteringKey = true; }
function enterLet16() { curLetter = letters[16]; enteringKey = true; }
function enterLet17() { curLetter = letters[17]; enteringKey = true; }
function enterLet18() { curLetter = letters[18]; enteringKey = true; }
function enterLet19() { curLetter = letters[19]; enteringKey = true; }
function enterLet20() { curLetter = letters[20]; enteringKey = true; }
function enterLet21() { curLetter = letters[21]; enteringKey = true; }
function enterLet22() { curLetter = letters[22]; enteringKey = true; }
function enterLet23() { curLetter = letters[23]; enteringKey = true; }
function enterLet24() { curLetter = letters[24]; enteringKey = true; }
function enterLet25() { curLetter = letters[25]; enteringKey = true; }

function circleGameWinScreen() {
  startCircleGameText = false;
  text("Sweet!!!", 30, 30)
  text("Now can you go back?", 300, 30)
}

function enterKeyboardGame2() {
  keyboardGame2 = true;
  typeEasyWordA = true;
  easyWordAPart1 = true;

}

function restartKeyboardGame1() {
  clear();
  keyboardGame1 = true;
  typeLetterA = true;

  keyboardGameCounterWrong = 0
}

function enterKeyboardGame3() {
  keyboardGame3 = true;
  typeHardWordA = true;
  hardWordAPart1 = true;
}
function timeIt() {
  if (timerValue > 0 && startCircleGameLoosingText == true|| startCircleGame2LoosingText == true) {
    timerValue--;
  }
}

function draw() {

  if (game1 == true) {
    textSize(30);
    cloudButton1.hide();
    cloudButton2.hide();
    cloudButton3.hide();
    backButton.show();
    // Show the needed buttons
    background(gameBackground);
    let d = dist(circlEx, circlEy, 350, 350);

    if((d < 150 )|| (circlEy > 550) || (circlEy <110) || (circlEx > 300 && circlEx < 380 && circlEy > 80 && circlEy<240)){
      circleGameLoss = true;
    }
  
    if (dragging) {
      circlEx = mouseX;
      circlEy = mouseY;
    }
    ellipse(350, 350, 400, 400)
    fill("white")
    noStroke();
    fill("white")
    rect(300, 110, 80, 130)
    rect(0,90,700,20)
    rect(0,550,700,20)
    fill("black")
    rect(270, 110, 40, 130)
    rect(380, 110, 40, 130)
    fill("white")
    ellipse(350, 350, 280, 280)
    fill("red")
    ellipse(circlEx, circlEy, diameter, diameter);
    fill("black")
    //
    if (circleGamePart1 == true) {
      
      if ( (circlEx < 400 || circlEx > 430 && circlEy < 130 || circlEy > 220) || (circlEx > 300 || circlEx < 380 && circlEy > 110 || circlEy < 280)) {

        startCircleGameText = false
        startCircleGameLoosingText = true

      }
      if ((d < 200 && d > 150) || (circlEx > 380 && circlEx < 420 && circlEy > 110 && circlEy < 220))  {
        startCircleGameLoosingText = false
        startCircleGameText = true
      }

      if ((circlEx > 270) && (circlEx < 310)) {
        if ((circlEy > 40) && (circlEy < 170)) {
          circleGamePart2 = true;
          circleGamePart1 = false;
        }
      }


      if (startCircleGameLoosingText == true) {
        text("RETURN TO THE BLACK!", 100, 30)

        if (timerValue >= 10) {
    text("0:" + timerValue, width / 2, height / 2);
  }
  if (timerValue < 10) {
    text('0:0' + timerValue, width / 2, height / 2);
  }
  if (timerValue == 0) {
    circleGameLoss = true;
  }
      }
      if (startCircleGameText == true) {
        text("Drag the red circle along the black ring. ", 50, 30);
        text("Make sure to stay in the black area.", 70, 80);
        textSize(24)
        text("If you touch the white, ",240,300)
          text("then you lose!",270,350)
      }
    }
    if (circleGamePart2 == true) {
      // startCircleGameText = false;

      let d = dist(circlEx, circlEy, 350, 350);
      if ((d > 180 || d < 150) || (circlEx < 400 || circlEx > 430 && circlEy < 130 || circlEy > 220) || (circlEx > 300 || circlEx < 380 && circlEy < 110 || circlEy > 220) || (circlEx > 270) && (circlEx < 310) && (circlEy > 40) && (circlEy < 170)) {

        startCircleGame2Text = false
        startCircleGame2LoosingText = true
      }
      if ((d < 180 && d > 150) || (circlEx > 380 && circlEx < 420 && circlEy > 110 && circlEy < 220) || (circlEx < 300 && circlEx > 380) || (circlEx > 270) && (circlEx < 310) && (circlEy > 40) && (circlEy < 220)) {
        startCircleGame2LoosingText = false
        startCircleGame2Text = true
      }

     
      if (startCircleGame2LoosingText == true) {
        text("RETURN TO THE BLACK!", 100, 30)
        if (timerValue >= 10) {
    text("0:" + timerValue, width / 2, height / 2);
  }
  if (timerValue < 10) {
    text('0:0' + timerValue, width / 2, height / 2);
  }
  if (timerValue == 0) {
    circleGameLoss = true;
  }
      }

      if (startCircleGame2Text == true) {
        text("Sweet!!!", 30, 30)
        text("Now can you go back?", 300, 30)

      }
    }
    if(circleGameLoss == true){
    clear()
      restartCircleGameButton.show();
    text("You've lost, try again!",220,50)
  }
     if (circleGameWin == true){
       background("black")
       textSize(130);
    fill(255, 0, 0, fade)
    text("You Win ", 50, 230);

    //noFill()
    //textSize(30)
    if (fade < 0){ 
      fadeAmount = 1;
    if (fade > 255) {
      fadeAmount = -10;
    fade += fadeAmount;
    }
    }
  }
  if((circlEx > 380 && circlEx < 420 && circlEy > 110 && circlEy < 220)&& circleGamePart2 == true){
  circleGameWin = true;
  circleGamePart2 = false;
  
}
  }
 
if(colorGameInstructions == true){
  textSize(40);
    cloudButton1.hide();
    cloudButton2.hide();
    cloudButton3.hide();
    backButton.show();
  colorGameNextButton.show()
    // Show the needed buttons
    background(gameBackground);
  text("Click a color, then click on a part", 100, 140);
  text("of the picture to color it in",130,220 )
}

  if (game2 == true) {
    colorGameNextButton.hide();
    cloudButton1.hide();
    cloudButton2.hide();
    cloudButton3.hide();
    backButton.show();
    redPaintButton.show();
  bluePaintButton.show();
  greenPaintButton.show();
  yellowPaintButton.show();
  blackPaintButton.show();
    // Show the needed buttons
    background(gameBackground);
    for (let i = 0; i < pictures.length; i++) {
      pictures[i].show();
    }

    tint("orange");
    image(images[0], x[0], y[0], W[0], H[0])
    noTint();
    image(images[2], x[2], y[2], W[2], H[2])
    image(BG1, 0, 200);
    image(BG2, 0, 0);
  }
  //
  if (game3 == true) {
    textSize(40);
    // Show the needed buttons
    cloudButton1.hide();
    cloudButton2.hide();
    cloudButton3.hide();
    backButton.show();
    // Change the background
    background("white");
fill("black")
    if (keyboardGame1 == true) {
      keyboardGame1RestartButton.hide();

      keyboardGame2Button.hide()
      for (let i = 0; i <= 25; i++) {
        keyboardB[i].show();
      }

      if (enteringKey == true) {
        print(curLetter)
        print(keyboardGameCounterWrong);
        enteringKey = false;
      }

      if (typeLetterA == true) {
        let A = text("Click: " + letterA, 300, 200)
        if (curLetter == letterA) {
          keyboardGameCounter++;
          typeLetterB = true;
          typeLetterA = false
          keyboardGameCounterWrong--;
          clear()
        }
        if (mouseIsPressed == true && curLetter != letterA) {
          keyboardGameCounterWrong++;
        }
      }

      if (typeLetterB == true) {
        text("Click: " + letterB, 300, 200)
        if (curLetter == letterB) {
          keyboardGameCounter++;
          typeLetterC = true;
          typeLetterB = false
          keyboardGameCounterWrong--;
          clear()
        }
        if (mouseIsPressed == true && curLetter != letterB) {
          keyboardGameCounterWrong++;
        }
      }

      if (typeLetterC == true) {
        text("Click: " + letterC, 300, 200)
        if (curLetter == letterC) {
          keyboardGameCounter++;
          keyboardGame2Button.show();
          keyboardGame1 = false;
          typeLetterC = false;
          
          keyboardGameCounterWrong = 0;
          for (let i = 0; i <= 25; i++) {
            keyboardB[i].hide();
          }
          clear()
        }
        if (mouseIsPressed == true && curLetter != letterC) {
          keyboardGameCounterWrong++;
        }
      }
    }
    //---------------Keyboardgame1^^^^^-------------------//



    if (keyboardGame2 == true) {
      for (let i = 0; i <= 25; i++) {
        keyboardB[i].show();
background(gameBackground);
      }
      keyboardGame1RestartButton.hide();

      keyboardGame2Button.hide();
      if (typeEasyWordA == true) {
        
        fill("black")
        text("type: " + easyWordA, 250, 200);
        fill("grey")
        text(easyWordA.charAt(0), 210, 300);
        text(easyWordA.charAt(1), 280, 300);
        text(easyWordA.charAt(2), 350, 300);
        text(easyWordA.charAt(3), 420, 300);
        if (easyWordAPart1 == true) {
          if (curLetter == easyWordA.charAt(0)) {
            clear();
            fill("black")
            text("type: " + easyWordA, 250, 200);
            fill("green");
            text(easyWordA.charAt(0), 210, 300)
            fill("grey");
            text(easyWordA.charAt(1), 280, 300);
            text(easyWordA.charAt(2), 350, 300);
            text(easyWordA.charAt(3), 420, 300);
            easyWordAPart2 = true;
            easyWordAPart1 = false;
          }
        }
        if (easyWordAPart2 == true) {
         
          if (curLetter == easyWordA.charAt(1)) {
            clear();
            fill("black")
            text("type: " + easyWordA, 250, 200);
            fill("green");
            text(easyWordA.charAt(0), 210, 300)
            text(easyWordA.charAt(1), 280, 300);
            fill("grey");
            text(easyWordA.charAt(2), 350, 300);
            text(easyWordA.charAt(3), 420, 300);
            easyWordAPart3 = true;
            easyWordAPart2 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordA, 250, 200);
            fill("green");
            text(easyWordA.charAt(0), 210, 300)
            fill("grey");
            text(easyWordA.charAt(1), 280, 300);
            text(easyWordA.charAt(2), 350, 300);
            text(easyWordA.charAt(3), 420, 300);
          }
        }
        if (easyWordAPart3 == true) {
          if (curLetter == easyWordA.charAt(2)) {
            clear();
            fill("black")
            text("type: " + easyWordA, 250, 200);
            fill("green");
            text(easyWordA.charAt(0), 210, 300)
            text(easyWordA.charAt(1), 280, 300);
            text(easyWordA.charAt(2), 350, 300);
            fill("grey");
            text(easyWordA.charAt(3), 420, 300);
            easyWordAPart4 = true;
            easyWordAPart3 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordA, 250, 200);
            fill("green");
            text(easyWordA.charAt(0), 210, 300)
            text(easyWordA.charAt(1), 280, 300);
            fill("grey");
            text(easyWordA.charAt(2), 350, 300);
            text(easyWordA.charAt(3), 420, 300);
          }
        }
        if (easyWordAPart4 == true) {
          if (curLetter == easyWordA.charAt(3)) {
            clear();
            fill("black")
            text("type: " + easyWordA, 250, 200);
            fill("green");
            text(easyWordA.charAt(0), 210, 300)
            text(easyWordA.charAt(1), 280, 300);
            text(easyWordA.charAt(2), 350, 300);
            text(easyWordA.charAt(3), 420, 300);
            typeEasyWordB = true;
            typeEasyWordA = false;
            easyWordBPart1 = true;
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordA, 250, 200);
            fill("green");
            text(easyWordA.charAt(0), 210, 300)
            text(easyWordA.charAt(1), 280, 300);
            text(easyWordA.charAt(2), 350, 300);
            fill("grey");
            text(easyWordA.charAt(3), 420, 300);
          }
        }
      }
      //  EasyWord B part;---------------------------------------------------
      if (typeEasyWordB == true) {
        clear();
        fill("black")
        text("type: " + easyWordB, 250, 200);
        fill("grey")
        text(easyWordB.charAt(0), 210, 300);
        text(easyWordB.charAt(1), 280, 300);
        text(easyWordB.charAt(2), 350, 300);
        text(easyWordB.charAt(3), 420, 300);
        if (easyWordBPart1 == true) {
          if (curLetter == easyWordB.charAt(0)) {
            clear();
            fill("black")
            text("type: " + easyWordB, 250, 200);
            fill("green");
            text(easyWordB.charAt(0), 210, 300)
            fill("grey");
            text(easyWordB.charAt(1), 280, 300);
            text(easyWordB.charAt(2), 350, 300);
            text(easyWordB.charAt(3), 420, 300);
            easyWordBPart2 = true;
            easyWordBPart1 = false;
          }
        }
        if (easyWordBPart2 == true) {
          if (curLetter == easyWordB.charAt(1)) {
            clear();
            fill("black")
            text("type: " + easyWordB, 250, 200);
            fill("green");
            text(easyWordB.charAt(0), 210, 300)
            text(easyWordB.charAt(1), 280, 300);
            fill("grey");
            text(easyWordB.charAt(2), 350, 300);
            text(easyWordB.charAt(3), 420, 300);
            easyWordBPart3 = true;
            easyWordBPart2 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordB, 250, 200);
            fill("green");
            text(easyWordB.charAt(0), 210, 300)
            fill("grey");
            text(easyWordB.charAt(1), 280, 300);
            text(easyWordB.charAt(2), 350, 300);
            text(easyWordB.charAt(3), 420, 300);
          }
        }
        if (easyWordBPart3 == true) {
          if (curLetter == easyWordB.charAt(2)) {
            clear();
            fill("black")
            text("type: " + easyWordB, 250, 200);
            fill("green");
            text(easyWordB.charAt(0), 210, 300)
            text(easyWordB.charAt(1), 280, 300);
            text(easyWordB.charAt(2), 350, 300);
            fill("grey");
            text(easyWordB.charAt(3), 420, 300);
            easyWordBPart4 = true;
            easyWordBPart3 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordB, 250, 200);
            fill("green");
            text(easyWordB.charAt(0), 210, 300)
            text(easyWordB.charAt(1), 280, 300);
            fill("grey");
            text(easyWordB.charAt(2), 350, 300);
            text(easyWordB.charAt(3), 420, 300);
          }
        }
        if (easyWordBPart4 == true) {
          if (curLetter == easyWordB.charAt(3)) {
            clear();
            fill("black")
            text("type: " + easyWordB, 250, 200);
            fill("green");
            text(easyWordB.charAt(0), 210, 300)
            text(easyWordB.charAt(1), 280, 300);
            text(easyWordB.charAt(2), 350, 300);
            text(easyWordB.charAt(3), 420, 300);
            typeEasyWordB = false;
            typeEasyWordC = true;
            easyWordCPart1 = true;
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordB, 250, 200);
            fill("green");
            text(easyWordB.charAt(0), 210, 300)
            text(easyWordB.charAt(1), 280, 300);
            text(easyWordB.charAt(2), 350, 300);
            fill("grey");
            text(easyWordB.charAt(3), 420, 300);
          }
        }
      }
      // EasyWordC part ---------------------------------------------------------
      if (typeEasyWordC == true) {
        clear();
        fill("black")
        text("type: " + easyWordC, 250, 200);
        fill("grey")
        text(easyWordC.charAt(0), 210, 300);
        text(easyWordC.charAt(1), 280, 300);
        text(easyWordC.charAt(2), 350, 300);
        text(easyWordC.charAt(3), 420, 300);
        if (easyWordCPart1 == true) {
          if (curLetter == easyWordC.charAt(0)) {
            clear();
            fill("black")
            text("type: " + easyWordC, 250, 200);
            fill("green");
            text(easyWordC.charAt(0), 210, 300)
            fill("grey");
            text(easyWordC.charAt(1), 280, 300);
            text(easyWordC.charAt(2), 350, 300);
            text(easyWordC.charAt(3), 420, 300);
            easyWordCPart2 = true;
            easyWordCPart1 = false;
          }
        }
        if (easyWordCPart2 == true) {
          if (curLetter == easyWordC.charAt(1)) {
            clear();
            fill("black")
            text("type: " + easyWordC, 250, 200);
            fill("green");
            text(easyWordC.charAt(0), 210, 300)
            text(easyWordC.charAt(1), 280, 300);
            fill("grey");
            text(easyWordC.charAt(2), 350, 300);
            text(easyWordC.charAt(3), 420, 300);
            easyWordCPart3 = true;
            easyWordCPart2 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordC, 250, 200);
            fill("green");
            text(easyWordC.charAt(0), 210, 300)
            fill("grey");
            text(easyWordC.charAt(1), 280, 300);
            text(easyWordC.charAt(2), 350, 300);
            text(easyWordC.charAt(3), 420, 300);
          }
        }
        if (easyWordCPart3 == true) {
          if (curLetter == easyWordC.charAt(2)) {
            clear();
            fill("black")
            text("type: " + easyWordC, 250, 200);
            fill("green");
            text(easyWordC.charAt(0), 210, 300)
            text(easyWordC.charAt(1), 280, 300);
            text(easyWordC.charAt(2), 350, 300);
            fill("grey");
            text(easyWordC.charAt(3), 420, 300);
            easyWordCPart4 = true;
            easyWordCPart3 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordC, 250, 200);
            fill("green");
            text(easyWordC.charAt(0), 210, 300)
            text(easyWordC.charAt(1), 280, 300);
            fill("grey");
            text(easyWordC.charAt(2), 350, 300);
            text(easyWordC.charAt(3), 420, 300);
          }
        }
        if (easyWordCPart4 == true) {
          if (curLetter == easyWordC.charAt(3)) {
            clear();
            fill("black")
            text("type: " + easyWordC, 250, 200);
            fill("green");
            text(easyWordC.charAt(0), 210, 300)
            text(easyWordC.charAt(1), 280, 300);
            text(easyWordC.charAt(2), 350, 300);
            text(easyWordC.charAt(3), 420, 300);
            keyboardGameCounterWrong = 0;
            typeEasyWordC = false;
            for (let i = 0; i <= 25; i++) {
              keyboardB[i].hide();
            }
            keyboardGame2 = false;
            keyboardGame3Button.show()
            clear();
          }
          else {
            clear();
            fill("black")
            text("type: " + easyWordC, 250, 200);
            fill("green");
            text(easyWordC.charAt(0), 210, 300)
            text(easyWordC.charAt(1), 280, 300);
            text(easyWordC.charAt(2), 350, 300);
            fill("grey");
            text(easyWordC.charAt(3), 420, 300);
          }
        }
      }
    }
    //-----------------------------------------------game 3-------------
    if (keyboardGame3 == true) {
      clear();
      for (let i = 0; i <= 25; i++) {
        keyboardB[i].show();

      }
      //keyboardGame1RestartButton.hide();
      // keyboardGameButton.hide()
      background(gameBackground);
      keyboardGame3Button.hide();
      if (typeHardWordA == true) {
        fill("black")
        text("type: " + hardWordA, 250, 200);
        fill("grey")
        text(hardWordA.charAt(0), 210, 300);
        text(hardWordA.charAt(1), 280, 300);
        text(hardWordA.charAt(2), 350, 300);
        text(hardWordA.charAt(3), 420, 300);
        text(hardWordA.charAt(4), 490, 300);
        text(hardWordA.charAt(5), 560, 300);
        if (hardWordAPart1 == true) {
          if (curLetter == hardWordA.charAt(0)) {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            fill("grey");
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
            hardWordAPart2 = true;
            hardWordAPart1 = false;
          }
        }
        if (hardWordAPart2 == true) {
          if (curLetter == hardWordA.charAt(1)) {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            fill("grey");
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
            hardWordAPart3 = true;
            hardWordAPart2 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            fill("grey");
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
          }
        }
        if (hardWordAPart3 == true) {
          if (curLetter == hardWordA.charAt(2)) {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            fill("grey");
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
            hardWordAPart4 = true;
            hardWordAPart3 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            fill("grey");
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
          }
        }
        if (hardWordAPart4 == true) {
          if (curLetter == hardWordA.charAt(3)) {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            fill("grey");
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
            hardWordAPart5 = true;
            hardWordAPart4 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            fill("grey");
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
          }
        }
        if (hardWordAPart5 == true) {
          if (curLetter == hardWordA.charAt(4)) {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            fill("grey");
            text(hardWordA.charAt(5), 560, 300);
            hardWordAPart6 = true;
            hardWordAPart5 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            fill("grey");
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
          }
        }
        if (hardWordAPart6 == true) {
          if (curLetter == hardWordA.charAt(5)) {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            text(hardWordA.charAt(5), 560, 300);
            typeHardWordA = false;
            typeHardWordB = true;
            hardWordBPart1 = true;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordA, 250, 200);
            fill("green");
            text(hardWordA.charAt(0), 210, 300)
            text(hardWordA.charAt(1), 280, 300);
            text(hardWordA.charAt(2), 350, 300);
            text(hardWordA.charAt(3), 420, 300);
            text(hardWordA.charAt(4), 490, 300);
            fill("grey");
            text(hardWordA.charAt(5), 560, 300);
          }
        }
      }
      //  EasyWord B part;---------------------------------------------------
      if (typeHardWordB == true) {
        clear();
        fill("black")
        text("type: " + hardWordB, 250, 200);
        fill("grey")
        text(hardWordB.charAt(0), 210, 300);
        text(hardWordB.charAt(1), 280, 300);
        text(hardWordB.charAt(2), 350, 300);
        text(hardWordB.charAt(3), 420, 300);
        text(hardWordB.charAt(4), 490, 300);
        text(hardWordB.charAt(5), 560, 300);
        if (hardWordBPart1 == true) {
          if (curLetter == hardWordB.charAt(0)) {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            fill("grey");
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);
            hardWordBPart2 = true;
            hardWordBPart1 = false;
          }
        }
        if (hardWordBPart2 == true) {
          if (curLetter == hardWordB.charAt(1)) {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            fill("grey");
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);
            hardWordBPart3 = true;
            hardWordBPart2 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            fill("grey");
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);
          }
        }
        if (hardWordBPart3 == true) {
          if (curLetter == hardWordB.charAt(2)) {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            fill("grey");
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);
            hardWordBPart4 = true;
            hardWordBPart3 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            fill("grey");
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);
          }
        }
        if (hardWordBPart4 == true) {
          if (curLetter == hardWordB.charAt(3)) {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            fill("grey");
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);

            hardWordBPart5 = true;
            hardWordBPart4 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            fill("grey");
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);
          }
        }
        if (hardWordBPart5 == true) {
          if (curLetter == hardWordB.charAt(4)) {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            fill("grey");
            text(hardWordB.charAt(5), 560, 300);
            hardWordBPart6 = true;
            hardWordBPart5 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            fill("grey");
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);
          }
        }
        if (hardWordBPart6 == true) {
          if (curLetter == hardWordB.charAt(5)) {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            text(hardWordB.charAt(5), 560, 300);
            typeHardWordB = false;
            typeHardWordC = true;
            hardWordCPart1 = true;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordB, 250, 200);
            fill("green");
            text(hardWordB.charAt(0), 210, 300)
            text(hardWordB.charAt(1), 280, 300);
            text(hardWordB.charAt(2), 350, 300);
            text(hardWordB.charAt(3), 420, 300);
            text(hardWordB.charAt(4), 490, 300);
            fill("grey");
            text(hardWordB.charAt(5), 560, 300);
          }
        }
      }

      // hardWordC part ---------------------------------------------------------
      if (typeHardWordC == true) {
        clear();
        fill("black")
        text("type: " + hardWordC, 250, 200);
        fill("grey")
        text(hardWordC.charAt(0), 210, 300);
        text(hardWordC.charAt(1), 280, 300);
        text(hardWordC.charAt(2), 350, 300);
        text(hardWordC.charAt(3), 420, 300);
        text(hardWordC.charAt(4), 490, 300);
        text(hardWordC.charAt(5), 560, 300);
        if (hardWordCPart1 == true) {
          if (curLetter == hardWordC.charAt(0)) {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            fill("grey");
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
            hardWordCPart2 = true;
            hardWordCPart1 = false;
          }
        }
        if (hardWordCPart2 == true) {
          if (curLetter == hardWordC.charAt(1)) {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            fill("grey");
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
            hardWordCPart3 = true;
            hardWordCPart2 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            fill("grey");
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
          }
        }
        if (hardWordCPart3 == true) {
          if (curLetter == hardWordC.charAt(2)) {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            fill("grey");
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
            hardWordCPart4 = true;
            hardWordCPart3 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            fill("grey");
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
          }
        }
        if (hardWordCPart4 == true) {
          if (curLetter == hardWordC.charAt(3)) {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            fill("grey");
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
            hardWordCPart5 = true;
            hardWordCPart4 = false;

          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            fill("grey");
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
          }
        }
        if (hardWordCPart5 == true) {
          if (curLetter == hardWordC.charAt(4)) {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            fill("grey");
            text(hardWordC.charAt(5), 560, 300);
            hardWordCPart6 = true;
            hardWordCPart5 = false;
          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            fill("grey");
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
          }
        }
        if (hardWordCPart6 == true) {
          if (curLetter == hardWordC.charAt(5)) {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            text(hardWordC.charAt(5), 560, 300);
            clear();
            for (let i = 0; i <= 25; i++) {
              keyboardB[i].hide();

            }
            typeHardWordC = false;
            keyboardGameWin = true;

          }
          else {
            clear();
            fill("black")
            text("type: " + hardWordC, 250, 200);
            fill("green");
            text(hardWordC.charAt(0), 210, 300)
            text(hardWordC.charAt(1), 280, 300);
            text(hardWordC.charAt(2), 350, 300);
            text(hardWordC.charAt(3), 420, 300);
            text(hardWordC.charAt(4), 490, 300);
            fill("grey");
            text(hardWordC.charAt(5), 560, 300);
          }
        }
      }
    }


    if (keyboardGameWin == true) {
      for(let j =0; j<255; j++){
        
      }
      text("You Win!!", 300, 300)
      for (let i = 0; i <= 25; i++) {
        keyboardB[i].hide();
      }
  hardWordAPart1, hardWordAPart2, hardWordAPart3, hardWordAPart4, hardWordAPart5, hardWordAPart6 = false;
  hardWordBPart1, hardWordBPart2, hardWordBPart3, hardWordBPart4, hardWordBPart5, hardWordBPart6 = false;
  hardWordCPart1, hardWordCPart2, hardWordCPart3, hardWordCPart4, hardWordCPart5, hardWordCPart6 = false;
  easyWordAPart1, easyWordAPart2, easyWordAPart3, easyWordAPart4 = false;
  easyWordBPart1, easyWordBPart2, easyWordBPart3, easyWordBPart4 = false;
  easyWordCPart1, easyWordCPart2, easyWordCPart3, easyWordCPart4 = false;
      
  letterA = random(letters);
  letterB = random(letters);
  letterC = random(letters);
  easyWordA = random(easyWords);
  easyWordB = random(easyWords);
  easyWordC = random(easyWords);
  hardWordA = random(hardWords);
  hardWordB = random(hardWords);
  hardWordC = random(hardWords);
    }
    if (keyboardGameCounterWrong > 33) {

      keyboardGame2Button.hide()
      for (let i = 0; i <= 25; i++) {
        keyboardB[i].hide();
      }
      keyboardGame1 = false;
      typeLetterA = false;
      typeLetterB = false;
      typeLetterC = false;
      clear();
      text("You Died", 300, 300);
      keyboardGame1RestartButton.show();
    }
  }
}

function mainPage() {
  // Show the needed buttons
  backButton.hide();
  cloudButton1.show();
  cloudButton2.show();
  cloudButton3.show();
  //Initialize background.
  background(gameBackground);
  textSize(20);
  //Draw credits text.
  fill(255);
  rect(90, 440, 520, 100);
  fill(0);
  text("Created by:", 280, 460);
  text("Andrew Ayerh, Brian Martinez Rosas, Maggie Nguyen,", 110, 500);
  text("Pranav Pokar, Kiernan Wyatt", 220, 530);
  textSize(40)
  text("Click on one of the 3 clouds below!",40,100)
  fill(500);
}

function circleGame() {
  game1 = true;
  startCircleGameText = true;
  startCircleGame = true;
  circleGamePart1 = true;
}

function paintGame() {
  colorGameInstructions = true;
}

function keyboardGame() {
  game3 = true;
  keyboardGame1 = true;
  typeLetterA = true;
}

function goBack() {
  timerValue = 10;
  game1 = false;
  game2 = false;
  game3 = false;
keyboardGame3 = false;
  keyboardGame2 = false;
  keyboardGameWin = false;
colorGameInstructions = false
  circleGameWin= false;
  circleGameLose = false;
  circlEx = 400;
  circlEy = 130;
  colorGameNextButton.hide();
  keyboardGame1RestartButton.hide()
hardWordAPart1, hardWordAPart2, hardWordAPart3, hardWordAPart4, hardWordAPart5, hardWordAPart6 = false;
  hardWordBPart1, hardWordBPart2, hardWordBPart3, hardWordBPart4, hardWordBPart5, hardWordBPart6 = false;
  hardWordCPart1, hardWordCPart2, hardWordCPart3, hardWordCPart4, hardWordCPart5, hardWordCPart6 = false;
  easyWordAPart1, easyWordAPart2, easyWordAPart3, easyWordAPart4 = false;
  easyWordBPart1, easyWordBPart2, easyWordBPart3, easyWordBPart4 = false;
  easyWordCPart1, easyWordCPart2, easyWordCPart3, easyWordCPart4 = false;
      
  letterA = random(letters);
  letterB = random(letters);
  letterC = random(letters);
  easyWordA = random(easyWords);
  easyWordB = random(easyWords);
  easyWordC = random(easyWords);
  hardWordA = random(hardWords);
  hardWordB = random(hardWords);
  hardWordC = random(hardWords);
  // Show the needed buttons
    restartCircleGameButton.hide();
  cloudButton1.hide();
  cloudButton1.hide();
  cloudButton1.hide();
  redPaintButton.hide();
  bluePaintButton.hide();
  greenPaintButton.hide();
  yellowPaintButton.hide();
  blackPaintButton.hide();
  // keyboardGame1RestartButton.hide();

  // keyboardGame2Button.hide()
  for (let i = 0; i <= 25; i++) {
    keyboardB[i].hide();
  }
  backButton.show();
  mainPage();
}

function changeColorToRed() {
  currentColor = "red";
}
function changeColorToBlue() {
  currentColor = "blue";
}
function changeColorToYellow() {
  currentColor = "yellow";
}
function changeColorToGreen() {
  currentColor = "green";
}
function changeColorToBlack() {
  currentColor = "black";
}

class Bubble1 {
  constructor(assignedX1, assignedY1, assignedW1, assignedH1, images) {
    this.x = assignedX1;
    this.y = assignedY1;
    this.r1 = assignedW1;
    this.r2 = assignedH1;
    this.image = images[1];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }
}


class Bubble3 {
  constructor(assignedX3, assignedY3, assignedW3, assignedH3, images) {
    this.x = assignedX3;
    this.y = assignedY3;
    this.r1 = assignedW3;
    this.r2 = assignedH3;
    this.image = images[3];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble4 {
  constructor(assignedX4, assignedY4, assignedW4, assignedH4, images) {
    this.x = assignedX4;
    this.y = assignedY4;
    this.r1 = assignedW4;
    this.r2 = assignedH4;
    this.image = images[4];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble5 {
  constructor(assignedX5, assignedY5, assignedW5, assignedH5, images) {
    this.x = assignedX5;
    this.y = assignedY5;
    this.r1 = assignedW5;
    this.r2 = assignedH5;
    this.image = images[5];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble6 {
  constructor(assignedX6, assignedY6, assignedW6, assignedH6, images) {
    this.x = assignedX6;
    this.y = assignedY6;
    this.r1 = assignedW6;
    this.r2 = assignedH6;
    this.image = images[6];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble7 {
  constructor(assignedX7, assignedY7, assignedW7, assignedH7, images) {
    this.x = assignedX7;
    this.y = assignedY7;
    this.r1 = assignedW7;
    this.r2 = assignedH7;
    this.image = images[7];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble8 {
  constructor(assignedX8, assignedY8, assignedW8, assignedH8, images) {
    this.x = assignedX8;
    this.y = assignedY8;
    this.r1 = assignedW8;
    this.r2 = assignedH8;
    this.image = images[8];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble9 {
  constructor(assignedX9, assignedY9, assignedW9, assignedH9, images) {
    this.x = assignedX9;
    this.y = assignedY9;
    this.r1 = assignedW9;
    this.r2 = assignedH9;
    this.image = images[9];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble10 {
  constructor(assignedX10, assignedY10, assignedW10, assignedH10, images) {
    this.x = assignedX10;
    this.y = assignedY10;
    this.r1 = assignedW10;
    this.r2 = assignedH10;
    this.image = images[10];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble11 {
  constructor(assignedX11, assignedY11, assignedW11, assignedH11, images) {
    this.x = assignedX11;
    this.y = assignedY11;
    this.r1 = assignedW11;
    this.r2 = assignedH11;
    this.image = images[11];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble12 {
  constructor(assignedX12, assignedY12, assignedW12, assignedH12, images) {
    this.x = assignedX12;
    this.y = assignedY12;
    this.r1 = assignedW12;
    this.r2 = assignedH12;
    this.image = images[12];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}

class Bubble13 {
  constructor(assignedX13, assignedY13, assignedW13, assignedH13, images) {
    this.x = assignedX13;
    this.y = assignedY13;
    this.r1 = assignedW13;
    this.r2 = assignedH13;
    this.image = images[13];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}
class Bubble14 {
  constructor(assignedX14, assignedY14, assignedW14, assignedH14, images) {
    this.x = assignedX14;
    this.y = assignedY14;
    this.r1 = assignedW14;
    this.r2 = assignedH14;
    this.image = images[14];
    this.col = color(currentColor);
  }

  clicked(px, py) {
    if (px > this.x && px < this.x + this.r1 &&
      py > this.y && py < this.y + this.r2) {
      this.col = color(currentColor);
    }
  }
  show() {
    tint(this.col, 125);
    image(this.image, this.x, this.y, this.r1, this.r2);
  }

}


